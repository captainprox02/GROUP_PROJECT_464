﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP_PROJECT
{
	public partial class frm_KhachHang : Form
	{
		public frm_KhachHang()
		{
			InitializeComponent();
		}

		public frm_KhachHang(string MaKhachHang)
		{
			InitializeComponent();
			MessageBox.Show(MaKhachHang);
		}
	}
}
