﻿namespace GROUP_PROJECT
{
	partial class frm_KhachHang
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_DatXe = new System.Windows.Forms.Button();
			this.btn_XemDanhSachThueXe = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btn_DatXe
			// 
			this.btn_DatXe.Location = new System.Drawing.Point(94, 175);
			this.btn_DatXe.Name = "btn_DatXe";
			this.btn_DatXe.Size = new System.Drawing.Size(106, 99);
			this.btn_DatXe.TabIndex = 0;
			this.btn_DatXe.Text = "Đặt xe";
			this.btn_DatXe.UseVisualStyleBackColor = true;
			// 
			// btn_XemDanhSachThueXe
			// 
			this.btn_XemDanhSachThueXe.Location = new System.Drawing.Point(297, 175);
			this.btn_XemDanhSachThueXe.Name = "btn_XemDanhSachThueXe";
			this.btn_XemDanhSachThueXe.Size = new System.Drawing.Size(106, 99);
			this.btn_XemDanhSachThueXe.TabIndex = 1;
			this.btn_XemDanhSachThueXe.Text = "Xem hợp đồng thuê xe";
			this.btn_XemDanhSachThueXe.UseVisualStyleBackColor = true;
			// 
			// frm_KhachHang
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(523, 450);
			this.Controls.Add(this.btn_XemDanhSachThueXe);
			this.Controls.Add(this.btn_DatXe);
			this.Name = "frm_KhachHang";
			this.Text = "frm_KhachHang";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button btn_DatXe;
		private System.Windows.Forms.Button btn_XemDanhSachThueXe;
	}
}