﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP_PROJECT
{
	public partial class frm_NhanVien : Form
	{
		public frm_NhanVien()
		{
			InitializeComponent();
		}

		public frm_NhanVien(string MaNhanVien)
		{
			InitializeComponent();
			MessageBox.Show(MaNhanVien);
		}
	}
}
