﻿namespace GROUP_PROJECT
{
	partial class frm_NhanVien
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_XemDanhSachThueXe = new System.Windows.Forms.Button();
			this.btn_DatXe = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btn_XemDanhSachThueXe
			// 
			this.btn_XemDanhSachThueXe.Location = new System.Drawing.Point(225, 103);
			this.btn_XemDanhSachThueXe.Name = "btn_XemDanhSachThueXe";
			this.btn_XemDanhSachThueXe.Size = new System.Drawing.Size(106, 99);
			this.btn_XemDanhSachThueXe.TabIndex = 3;
			this.btn_XemDanhSachThueXe.Text = "Quản Lý Xe Chở Hàng";
			this.btn_XemDanhSachThueXe.UseVisualStyleBackColor = true;
			// 
			// btn_DatXe
			// 
			this.btn_DatXe.Location = new System.Drawing.Point(80, 103);
			this.btn_DatXe.Name = "btn_DatXe";
			this.btn_DatXe.Size = new System.Drawing.Size(106, 99);
			this.btn_DatXe.TabIndex = 2;
			this.btn_DatXe.Text = "Quản Lý Xe Du Lịch";
			this.btn_DatXe.UseVisualStyleBackColor = true;
			// 
			// frm_NhanVien
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.btn_XemDanhSachThueXe);
			this.Controls.Add(this.btn_DatXe);
			this.Name = "frm_NhanVien";
			this.Text = "frm_NhanVien";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button btn_XemDanhSachThueXe;
		private System.Windows.Forms.Button btn_DatXe;
	}
}