﻿namespace GROUP_PROJECT
{
	partial class frm_ThemXeDuLich
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_ThemXeDuLich));
			this.txt_SoChoNgoi = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txt_TieuChuanBang = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.date_NgayDangKiem = new System.Windows.Forms.DateTimePicker();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txt_TrongTai = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txt_TenXe = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txt_BienSo = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txt_MaXe = new System.Windows.Forms.TextBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label8 = new System.Windows.Forms.Label();
			this.btn_Them = new System.Windows.Forms.Button();
			this.btn_Thoat = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// txt_SoChoNgoi
			// 
			this.txt_SoChoNgoi.Location = new System.Drawing.Point(158, 283);
			this.txt_SoChoNgoi.Name = "txt_SoChoNgoi";
			this.txt_SoChoNgoi.Size = new System.Drawing.Size(148, 20);
			this.txt_SoChoNgoi.TabIndex = 28;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(55, 283);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(64, 13);
			this.label7.TabIndex = 27;
			this.label7.Text = "Số chỗ ngồi";
			// 
			// txt_TieuChuanBang
			// 
			this.txt_TieuChuanBang.Location = new System.Drawing.Point(158, 240);
			this.txt_TieuChuanBang.Name = "txt_TieuChuanBang";
			this.txt_TieuChuanBang.Size = new System.Drawing.Size(148, 20);
			this.txt_TieuChuanBang.TabIndex = 26;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(55, 240);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(88, 13);
			this.label6.TabIndex = 25;
			this.label6.Text = "Tiêu chuẩn bằng";
			// 
			// date_NgayDangKiem
			// 
			this.date_NgayDangKiem.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.date_NgayDangKiem.Location = new System.Drawing.Point(158, 198);
			this.date_NgayDangKiem.Name = "date_NgayDangKiem";
			this.date_NgayDangKiem.Size = new System.Drawing.Size(148, 20);
			this.date_NgayDangKiem.TabIndex = 24;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(55, 198);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(85, 13);
			this.label5.TabIndex = 23;
			this.label5.Text = "Ngày đăng kiểm";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(55, 157);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(49, 13);
			this.label4.TabIndex = 22;
			this.label4.Text = "Trọng tải";
			// 
			// txt_TrongTai
			// 
			this.txt_TrongTai.Location = new System.Drawing.Point(158, 157);
			this.txt_TrongTai.Name = "txt_TrongTai";
			this.txt_TrongTai.Size = new System.Drawing.Size(148, 20);
			this.txt_TrongTai.TabIndex = 21;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(55, 118);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(40, 13);
			this.label3.TabIndex = 20;
			this.label3.Text = "Tên xe";
			// 
			// txt_TenXe
			// 
			this.txt_TenXe.Location = new System.Drawing.Point(158, 118);
			this.txt_TenXe.Name = "txt_TenXe";
			this.txt_TenXe.Size = new System.Drawing.Size(148, 20);
			this.txt_TenXe.TabIndex = 19;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(55, 76);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(42, 13);
			this.label2.TabIndex = 18;
			this.label2.Text = "Biển số";
			// 
			// txt_BienSo
			// 
			this.txt_BienSo.Location = new System.Drawing.Point(158, 76);
			this.txt_BienSo.Name = "txt_BienSo";
			this.txt_BienSo.Size = new System.Drawing.Size(148, 20);
			this.txt_BienSo.TabIndex = 17;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(55, 39);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(36, 13);
			this.label1.TabIndex = 16;
			this.label1.Text = "Mã xe";
			// 
			// txt_MaXe
			// 
			this.txt_MaXe.Location = new System.Drawing.Point(158, 39);
			this.txt_MaXe.Name = "txt_MaXe";
			this.txt_MaXe.Size = new System.Drawing.Size(148, 20);
			this.txt_MaXe.TabIndex = 15;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
			this.pictureBox1.Location = new System.Drawing.Point(368, 39);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(225, 264);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 29;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(427, 306);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(104, 15);
			this.label8.TabIndex = 30;
			this.label8.Text = "Nhập hình ảnh xe";
			// 
			// btn_Them
			// 
			this.btn_Them.Location = new System.Drawing.Point(430, 357);
			this.btn_Them.Name = "btn_Them";
			this.btn_Them.Size = new System.Drawing.Size(75, 23);
			this.btn_Them.TabIndex = 31;
			this.btn_Them.Text = "Thêm";
			this.btn_Them.UseVisualStyleBackColor = true;
			this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
			// 
			// btn_Thoat
			// 
			this.btn_Thoat.Location = new System.Drawing.Point(518, 357);
			this.btn_Thoat.Name = "btn_Thoat";
			this.btn_Thoat.Size = new System.Drawing.Size(75, 23);
			this.btn_Thoat.TabIndex = 32;
			this.btn_Thoat.Text = "Thoát";
			this.btn_Thoat.UseVisualStyleBackColor = true;
			this.btn_Thoat.Click += new System.EventHandler(this.btn_Thoat_Click);
			// 
			// frm_ThemXeDuLich
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(642, 401);
			this.Controls.Add(this.btn_Thoat);
			this.Controls.Add(this.btn_Them);
			this.Controls.Add(this.txt_SoChoNgoi);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.txt_TieuChuanBang);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.date_NgayDangKiem);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txt_TrongTai);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txt_TenXe);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txt_BienSo);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txt_MaXe);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.pictureBox1);
			this.Name = "frm_ThemXeDuLich";
			this.Text = "frm_ThemXeDuLich";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button btn_Them;
		private System.Windows.Forms.Button btn_Thoat;
		public System.Windows.Forms.TextBox txt_SoChoNgoi;
		public System.Windows.Forms.TextBox txt_TieuChuanBang;
		public System.Windows.Forms.DateTimePicker date_NgayDangKiem;
		public System.Windows.Forms.TextBox txt_TrongTai;
		public System.Windows.Forms.TextBox txt_TenXe;
		public System.Windows.Forms.TextBox txt_BienSo;
		public System.Windows.Forms.TextBox txt_MaXe;
		public System.Windows.Forms.PictureBox pictureBox1;
	}
}